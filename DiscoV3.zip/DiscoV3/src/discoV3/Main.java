package discoV3;

public class Main {

	public static void main(String[] args) {
		Disco di = new Disco();
		
		Pista pi1 = new Pista();
		Pista pi2 = new Pista();
		Pista pi3 = new Pista();
		Pista pi4 = new Pista();
		
		Customer cu = new Customer(di, pi1, pi2, pi3, pi4);
		
		while (true) {
			
			Thread th = new Thread(cu);
			
			th.start();
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
			System.out.println("numero di clienti totali: " + di.getCount());
			System.out.println("numero clienti pista 1: " + pi1.getNum_persone());
			System.out.println("numero clienti pista 2: " + pi2.getNum_persone());
			System.out.println("numero clienti pista 3: " + pi3.getNum_persone());
			System.out.println("numero clienti pista 4: " + pi4.getNum_persone());
		
		}
	
	}

}
