package discoV3;

import java.util.concurrent.ThreadLocalRandom;



public class Customer implements Runnable{

	private Disco dis;
	
	private int pista1;
	private int pista2;
	

	private Pista pis1;
	private Pista pis2;
	private Pista pis3;
	private Pista pis4;
	
	public Customer(Disco d, Pista p1, Pista p2, Pista p3, Pista p4) {
		
		setPista1(0);
		setPista2(0);
		
		setDis(d);
		
		setPis1(p1);
		setPis2(p2);
		setPis3(p3);
		setPis4(p4);
	
	}
	
	
	
	public void run() {
		
		int rand_wait;
		int rand_n_person = ThreadLocalRandom.current().nextInt(2,10);
		boolean in = false;
		
		while (true) {
			rand_wait = ThreadLocalRandom.current().nextInt(0,1000);
			
			try {
				Thread.sleep(rand_wait);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
			pista1 = ThreadLocalRandom.current().nextInt(1,5);
			
			switch(pista1) {
			
			case 1:
				if (!in) {
					dis.enter(rand_n_person);
					in= !in;
					
					pis1.enter_room(rand_n_person);
				}else {

					pis1.enter_room(rand_n_person);
				
					evened_num(rand_n_person);
				}
				pista2 = pista1;
				break;
				
			case 2:
				if (!in) {
					dis.enter(rand_n_person);
					in= !in;
					
					pis2.enter_room(rand_n_person);
				}else {

					pis2.enter_room(rand_n_person);
				
					evened_num(rand_n_person);
				}
				pista2 = pista1;
				break;
				
			case 3:
				if (!in) {
					dis.enter(rand_n_person);
					in= !in;
					
					pis3.enter_room(rand_n_person);
				}else {

					pis3.enter_room(rand_n_person);
				
					evened_num(rand_n_person);
				}
				pista2 = pista1;
				break;
				
			case 4:
				if (!in) {
					dis.enter(rand_n_person);
					in= !in;
					
					pis4.enter_room(rand_n_person);
				}else {

					pis4.enter_room(rand_n_person);
				
					evened_num(rand_n_person);
				}
				pista2 = pista1;
				break;
				
			case 5:
				if (in) {
					dis.exit(rand_n_person);
					in= !in;
				
					evened_num(rand_n_person);
				}
				
				
				break;
			}
		}
		
	}
	
	private void evened_num(int num) {
		
		switch(pista2) {
		
		case 1:
			pis1.exit_room(num);
			break;
		
		case 2:
			pis2.exit_room(num);
			break;
		
		case 3:
			pis3.exit_room(num);
			break;
		
		case 4:
			pis4.exit_room(num);
			break;
		
		}
		
		
	}
	
	public Disco getDis() {
		return dis;
	}

	public void setDis(Disco dis) {
		this.dis = dis;
	}

	public int getPista1() {
		return pista1;
	}


	public void setPista1(int pista1) {
		this.pista1 = pista1;
	}


	public int getPista2() {
		return pista2;
	}


	public void setPista2(int pista2) {
		this.pista2 = pista2;
	}


	public Pista getPis1() {
		return pis1;
	}

	public void setPis1(Pista pis1) {
		this.pis1 = pis1;
	}

	public Pista getPis2() {
		return pis2;
	}

	public void setPis2(Pista pis2) {
		this.pis2 = pis2;
	}

	public Pista getPis3() {
		return pis3;
	}

	public void setPis3(Pista pis3) {
		this.pis3 = pis3;
	}

	public Pista getPis4() {
		return pis4;
	}

	public void setPis4(Pista pis4) {
		this.pis4 = pis4;
	}

}