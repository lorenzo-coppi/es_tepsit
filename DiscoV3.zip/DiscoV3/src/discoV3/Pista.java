package discoV3;

public class Pista {

	private int num_persone;
	
	public Pista() {
		
		setNum_persone(0);
		
	}
	
	
	public synchronized void enter_room (int num) {
		
		setNum_persone(getNum_persone() + num);
		
	}
	
	public synchronized void exit_room (int num) {
		
		setNum_persone(getNum_persone() - num);
	}

	public int getNum_persone() {
		return num_persone;
	}

	public void setNum_persone(int num_persone) {
		this.num_persone = num_persone;
	}
	
}
