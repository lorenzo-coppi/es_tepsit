package es_teatro;

public class Seats { //entità passiva

	private int [][]seats;
	private int tot_seats;
	
	public Seats() {
		
		setTot_seats( 15 * 46);
		
		this.seats = new int [15][46];
		for (int i = 0; i < 15; i++) {
			for (int x = 0; x < 46; x++) {
				seats[i][x] = 1;
			}
		}
	}

	public synchronized void book(int num) {
		
		int row = 15;  // Numero di righe
	    int col = 46;  // Numero di colonne
	    int centerRow = row / 2;
	    int centerCol = col / 2;
	    boolean bool;
	    
	    for (int i = 0; i < num; i++) {
	        if (getTot_seats() == 0) {
	            System.out.println("I posti sono esauriti");
	            return;
	        }
	        bool = false;
	            
	        for (int layer = 0; layer <= Math.max(centerRow, centerCol) && !bool; layer++) {
	            for (int z = Math.max(0, centerRow - layer); z <= Math.min(row - 1, centerRow + layer) && !bool; z++) {
	                for (int j = Math.max(0, centerCol - layer); j <= Math.min(col - 1, centerCol + layer) && !bool; j++) {
	                    if (this.seats[z][j] == 1) {
	                        this.seats[z][j] = this.seats[z][j] - 1;  // Prenota il posto (sottrae 1 in modo da vedere se si si effettuato la doppia prenotazione dello stesso posto)
	                        setTot_seats(getTot_seats() - 1);  // Decrementa il numero di posti totali
	                        bool = true;
	                    }
	                }
	            }
	        }
	    }  			
	}

	public void print () {
		System.out.println("1 = posto non prenotato, 0 = posto prenotato");
		
		for (int i = 0; i < 15; i++) {
			for (int x = 0; x < 46; x++) {
				System.out.print(seats[i][x] + "\t");
			}
		System.out.println();
		}
		
	}
	

	
	public int getTot_seats() {
		return tot_seats;
	}

	public void setTot_seats(int tot_seats) {
		this.tot_seats = tot_seats;
	}

}


