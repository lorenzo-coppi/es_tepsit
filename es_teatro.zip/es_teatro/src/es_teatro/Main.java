package es_teatro;

public class Main { // entità attiva

	public static void main(String[] args) {
		
		Seats se = new Seats();
		Spettatore sp = new Spettatore(se);
		
		
		se.print();
		for (int i = 0; i < 7; i++) {

			Thread th = new Thread(sp);
			
			th.start();
		}

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		se.print();
		
	}

}
