package es_teatro;

import java.util.concurrent.ThreadLocalRandom;

public class Spettatore implements Runnable{ // entità attiva

	private Seats sea;
	
	public Spettatore(Seats s) {
		this.sea = s;
		
	}
	
	public void run() {
		int customers = ThreadLocalRandom.current().nextInt(0,200);
		
		this.sea.book(customers);
		
	}

}
