package prod_consumatori;

public class Consumer implements Runnable{

	private int []pos;
	private Buffer b;

	private int num;
	private int neg;
	private int old_pos;
	private int Count;
	private int avg;
	
	public Consumer(Buffer B) {
		
		this.setOld_pos(0);
		this.pos = new int [5];
		this.b = B; 
		this.setNeg(0);
		this.setAvg(0);
		
	}
	

		public void run() {
			
			int x = 0;
			
			while(true) {
				
				synchronized(b) {
					try {
		                
						this.setNum(b.remove());
						
		                    if (this.getNum() < 0) {
		                        setNeg(this.getNeg() + 1);
		                    } else if (check_full()) {
		                        	
		                        	pos[getOld_pos()] = getNum();
		                        	this.setOld_pos((getOld_pos() + 1) % 5);
		                        	
		                        	x = getOld_pos();
		                        	setAvg(0);
		                        	for(int i = 0; i < 5; i++, x = (x + 1) % 5) {
		                        		setAvg(pos[x] + getAvg());
		                        	}
		                        	
		                        }else {
		                        	x = getOld_pos();
		                        	
		                        	pos[(getOld_pos() + getCount()) %5] = getNum();
		                        	
		                        	setCount(getCount() + 1);
		                        	setAvg(0);
		                        	for(int i = 0; i < getCount(); i++, x = (x + 1) % 5) {
		                        		setAvg(pos[x] + getAvg());
		                        	}	
		                        }
		                    System.out.println("numeri negativi passati: " + getNeg() + " media ultimi 5 num positivi: " + getAvg()/5);

		                    try {
		                    Thread.sleep(100);
		                    }catch (InterruptedException e) {
		                    e.printStackTrace();
		                    }
		            } catch (Exception e) {
		                
		                try {
		                    System.out.println("Buffer vuoto, in attesa...");
		                    b.wait();  
		                } catch (InterruptedException ie) {
		                    
		                    ie.printStackTrace();
		                }
		            }
				}
		}
	}

		private Boolean check_full() {
			
			return Count == 5;
			
		}
		
		public int getCount() {
			return Count;
		}


		public void setCount(int count) {
			Count = count;
		}


		public int getNeg() {
			return neg;
		}


		public void setNeg(int neg) {
			this.neg = neg;
		}
		
		
		public int getAvg() {
			return avg;
		}


		public void setAvg(int avg) {
			this.avg = avg;
		}


		public int getNum() {
			return num;
		}


		public void setNum(int num) {
			this.num = num;
		}


		public int getOld_pos() {
			return old_pos;
		}


		public void setOld_pos(int old_num) {
			this.old_pos = old_num;
		}


}
