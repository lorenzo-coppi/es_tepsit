package prod_consumatori;

import java.util.concurrent.ThreadLocalRandom;

public class Producer implements Runnable{
	private Buffer b;
	private int x;
	
	public Producer (Buffer B) {
		b = B;
		
	}

	public void run () {
		
		while (true) {
			synchronized (b) {
				x = ThreadLocalRandom.current().nextInt(-1024 , 1023);
				b.add(x);
				
				b.notifyAll();
			}
			if(x < 0) {
				
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			}
			
			try {
				Thread.sleep(100 * 50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}
