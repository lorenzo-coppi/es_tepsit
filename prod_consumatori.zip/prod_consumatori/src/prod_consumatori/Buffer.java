package prod_consumatori;

public class Buffer {

	private int S;
	private int E;
	private int Count;
	
	private int []Buff;
	
	public Buffer() {
		
		this.setS(0);
		this.setE(0);
		this.setCount(0);
		
		Buff = new int[10];
	}	
	
	

	private Boolean check_empty() {
		
		return this.getE() == this.getS() && Count == 0;
		
	}
	
	private Boolean check_full() {
		
		return this.getE() == this.getS() && Count == 10;
	}
	
	public synchronized int add(int num) {
		
		if (this.check_full()) {
			
			System.out.println("buffer è pieno, aggiunta fallita");
			return -1;
			
		}else {
			
			Buff[this.getE()] = num;
			
			this.setE((getE() + 1) % 10);
			this.setCount(getCount() + 1);
			
			System.out.println("successo");
			return 0;
			
		}
	}
	
	public synchronized int remove ()  throws Exception{
		int x;
		if (this.check_empty()) {
			
			throw new Exception("Buffer è vuoto, rimozione fallita");
			
		}else {
			
			x =  Buff[this.getS()];
			this.setS((getS() + 1) % 10);
			this.setCount(this.getCount() - 1);
			
			System.out.println("successo");
			return x;
			
		}
	}

		public synchronized void print () {
			int x = S;
			
			System.out.println();
			
			for (int i = 0; i<Count; i++, x = x % 10) {
				
				System.out.println(Buff[x]);
			} 
			System.out.println();
			return;
		}
			
	public int getCount() {
		return Count;
	}

	public void setCount(int count) {
		Count = count;
	}
	public int getS() {
		return S;
	}
	public void setS(int s) {
		S = s;
	}
	public int getE() {
		return E;
	}
	public void setE(int e) {
		E = e;
	}
	
}
