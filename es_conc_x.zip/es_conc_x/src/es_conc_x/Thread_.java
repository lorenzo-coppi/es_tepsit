package es_conc_x;

import java.util.concurrent.ThreadLocalRandom;

public class Thread_ implements Runnable{

	Augment aug;
	
	int n;
	int val;
	
	
	public Thread_(Augment a) {
		this.aug = a;
		
		this.n = 30;
		this.val = 0;
	}	
	
	public void run() {
		int x = ThreadLocalRandom.current().nextInt(0, getN());
		
		for (int i = 0; i <= x; i++) {
			
			setVal(aug.inc());
			
			try {
				Thread.sleep(120);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	
	public int getVal() {
		return val;
	}

	public void setVal(int val) {
		this.val = val;
	}

	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}

}
