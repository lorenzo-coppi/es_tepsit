package es_conc_x;

public class Main {

	public static void main(String[] args) {
		
		int count = 0;
		int t = 5;
		
		Augment []au = new Augment[20];
		Thread_ []th = new Thread_[20];
		Thread []TH = new Thread[20];
		
		for (int i = 0; i < t; i++) {
			au[i] = new Augment();
			th[i] = new Thread_(au[i]);
			TH[i] = new Thread(th[i]);
			
			TH[i].start();
		}
		
		while (count != t) {
			count = 0;
			for (int i = 0; i < t; i++) {
				
				if(TH[i].isAlive()) {
					System.out.println(TH[i].getName() + " stato: " + TH[i].getState() + " numero: " + th[i].getVal());	
				}else {
					System.out.println(TH[i].getName() + " stato: " + TH[i].getState() + " numero: COMPLETATO");
					count++;
				}	
			}
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("TUTTI I THREAD COMPLETATI");
	}

}
