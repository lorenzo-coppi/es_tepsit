package es_conc_x;

public class Augment {

	private int count;
	
	public Augment(){
		
		this.count = 0;
		
	}
	
	public synchronized int inc () {
		
		setCount(getCount()+1);
		return getCount();
	} 
	
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}	
}
