package prod_consV2;

public class Consumer implements Runnable{

	private Buffer b;
	
	private int y;
	private int even;
	private int odd;
	
	public Consumer (Buffer B) {
		this.b = B;
		
		setEven(0);
		setOdd(0);
	}
	
	public void run() {
		setEven(0);
		setOdd(0);
		while(true) {
			
			synchronized(b) {
				setY(b.remove());
			
				if (y != -1) {
					System.out.println(y);
					if(getY() % 2 == 0) {
						setEven(getEven() + 1);
					}else {
						setOdd(getOdd() + 1);
					}
					
					System.out.println("numeri pari: " + getEven() + "numeri dispari: " + getOdd());
				}else {
					try {
						
						b.wait();
						System.out.println("in attesa");
					
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					}
				}
			}
		}
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getEven() {
		return even;
	}

	public void setEven(int even) {
		this.even = even;
	}

	public int getOdd() {
		return odd;
	}

	public void setOdd(int odd) {
		this.odd = odd;
	}
	
	
	
}