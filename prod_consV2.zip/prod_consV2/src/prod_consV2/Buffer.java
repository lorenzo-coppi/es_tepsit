package prod_consV2;

public class Buffer {

	private int E;
	private int Count;
	
	private int []Buff;
	
	public Buffer() {
		
		this.setE(0);
		this.setCount(0);
		
		Buff = new int[10];
	}	
	
	

	private Boolean check_empty() {
		
		return getCount() == 0;
		
	}
	
	private Boolean check_full() {
		
		return getCount() == 10;
	}
	
	public synchronized int add(int num) {
		
		if (this.check_full()) {
			
			System.out.println("buffer è pieno, aggiunta fallita");
			return -1;
			
		}else {
			
			Buff[this.getE()] = num;
			
			this.setE(getE() + 1);
			this.setCount(getCount() + 1);
			
			System.out.println("successo");
			return 0;
			
		}
	}
	
	public synchronized int remove (){
		int x;
		if (this.check_empty()) {
			
			System.out.println("buffer è vuoto, rimozione fallita");
			return -1;
		}else {
			
			x =  Buff[this.getE() - 1];
			this.setE(getE() - 1);
			this.setCount(this.getCount() - 1);
			
			System.out.println("successo");
			return x;
			
		}
	}

		public synchronized void print () {
			
			System.out.println();
			
			for (int i = 0; i<Count; i++) {
				
				System.out.println(Buff[i]);
			} 
			System.out.println();
			return;
		}
			
	public int getCount() {
		return Count;
	}

	public void setCount(int count) {
		Count = count;
	}
	
	public int getE() {
		return E;
	}
	
	public void setE(int e) {
		E = e;
	}

}