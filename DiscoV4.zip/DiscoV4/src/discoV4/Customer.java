package discoV4;

import java.util.concurrent.ThreadLocalRandom;

public class Customer implements Runnable{

	private Disco dis;
	
	public Customer(Disco d) {
		
		this.dis = d;
	}
	
	public void run() {
		
		int rand_wait;
		int rand_n_person = ThreadLocalRandom.current().nextInt(2,10);
		
		while (true) {
			rand_wait = ThreadLocalRandom.current().nextInt(0,1000);
			
			synchronized (dis) {
                if (dis.entrance(rand_n_person) == -1) {
                    try {
                        // Aspetta sul monitor dell'oggetto Disco
                        dis.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
			
			try {
				Thread.sleep(rand_wait);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			dis.exit(rand_n_person);
		}
		
	}
}