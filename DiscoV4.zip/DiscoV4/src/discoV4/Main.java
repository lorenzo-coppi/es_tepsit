package discoV4;

public class Main {

	public static void main(String[] args) {
		
		int count = 0;
		
		Disco di = new Disco();
		Customer cu = new Customer(di);
		
		Thread []th = new Thread[100];
		
		while (true) {
			
			th[count] = new Thread(cu);
			
			th[count].start();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
			
			System.out.println("persone nella discoteca: " + di.getCount());
			
			System.out.println("Thread in attesa");
			for (int i = 0; i < count; i++) {
				
				if (th[i].getState() == Thread.State.TIMED_WAITING) {
					
					System.out.print(th[i].getName() + " - " + "\t");		
				}
				
				System.out.println();
			}
			count++;
		}
	}

}
