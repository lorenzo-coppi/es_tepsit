package discoV4;

public class Disco {
	
	private int count;
	private int capacity;
	
	
	public Disco() {
		
		setCapacity(16);
		setCount(0);
		
	}
	
	public synchronized int entrance(int per) {
		if (getCount() + per > getCapacity()) {
			
			return -1;
		}else {
		
			setCount(getCount() + per);
			return 0;
		}
	}
	
	public synchronized void exit(int per) {
		setCount(getCount() - per);
		
		notifyAll();
	}
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

}
