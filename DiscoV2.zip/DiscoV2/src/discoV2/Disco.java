package discoV2;

public class Disco {
	
private int count;
	
	public Disco() {
		setCount(0);
		
	}
	
	public void entrance(int per) {
		setCount(getCount() + per);
		
	}
	
	public void exit(int per) {
		setCount(getCount() - per);
	}
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
}
