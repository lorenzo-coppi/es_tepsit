package discoteca;

import java.util.concurrent.ThreadLocalRandom;

public class Customer implements Runnable{

	Disco dis;
	
	public Customer(Disco d) {
		
		this.dis = d;
	}
	
	public void run() {
		int rand;
		while (true) {
			rand = ThreadLocalRandom.current().nextInt(0,1000);
			
			dis.entrance();
			
			try {
				Thread.sleep(rand);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			dis.exit();
		}
		
	}

}
