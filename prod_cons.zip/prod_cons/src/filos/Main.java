package filos;

public class Main {

	public static void main(String[] args) {
		
		Buffer bu = new Buffer();
		Consumer co = new Consumer(bu);
		Producer pr = new Producer(bu);
			
		
				
			Thread uno = new Thread(co);
			Thread due = new Thread(pr);
			
			uno.start();
			due.start();
			
			while(true) {
			
				bu.print();
				
				try {
					
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

}
