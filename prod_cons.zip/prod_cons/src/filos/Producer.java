package filos;

import java.util.concurrent.ThreadLocalRandom;

public class Producer implements Runnable{
	
	private Buffer b;
	private int x;
	
	public Producer (Buffer B) {
		b = B;
		x = 15;
	}

	public void run () {
		
		while (true) {
			synchronized (b) {
				x = ThreadLocalRandom.current().nextInt(0, 1023);
				b.add(x);
				
				b.notifyAll();
			
			}
			try {
				Thread.sleep(ThreadLocalRandom.current().nextInt(100,1000));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}
